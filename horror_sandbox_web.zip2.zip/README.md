# Untitled Horror Sandbox (web)

Runs in the browser with Three.js (loaded from the jsDelivr CDN). No build step.

## Publish on GitHub Pages
1. Create a new GitHub repo and upload everything in this folder (index.html, js/, README.md) to the root.
2. Repo Settings -> Pages -> Build and deployment -> Source: "Deploy from a branch" -> Branch: `main`, folder `/ (root)` -> Save.
3. After a minute your game is live at `https://<your-username>.github.io/<repo-name>/`.

## Run locally
ES modules need http (not file://):  `python3 -m http.server 8000`  then open http://localhost:8000

## Controls
WASD, Shift sprint, Ctrl crouch, Space jump, hold LMB mine, RMB place, 1-9 / wheel select, F flashlight, Esc release mouse.
Edits save automatically to this browser's localStorage.

## Status
Day 1 port, NOT yet tested in a browser (written without browser access).
Multiplayer plan: GitHub Pages is static, so it needs WebRTC peer-to-peer (host-authoritative) or a small WebSocket server.
